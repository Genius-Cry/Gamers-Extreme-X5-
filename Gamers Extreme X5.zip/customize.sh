#!/system/bin/sh
# customize.sh - Additional customizations for Gamers Extreme X5 by Genius _Cry
# This script performs conflict detection and sets file permissions.
#!/system/bin/sh

# Magisk module installation context variables
MODDIR=${0%/*}
INFOFILE="$MODDIR/device_info.log"

# Clean and prepare info file
rm -f "$INFOFILE"
touch "$INFOFILE"

# UI display and logging function
log_info() {
    ui_print "$1"
    echo "$1" >> "$INFOFILE"
}

# Begin collecting device information
ui_print " "
ui_print "Collecting device information..."
ui_print "Logging to: $INFOFILE"

log_info "===== Device Information ====="
log_info "Manufacturer: $(getprop ro.product.manufacturer)"
log_info "Brand: $(getprop ro.product.brand)"
log_info "Model: $(getprop ro.product.model)"
log_info "Device: $(getprop ro.product.device)"
log_info "Product: $(getprop ro.build.product)"
log_info "Hardware: $(getprop ro.hardware)"
log_info "Board: $(getprop ro.product.board)"
sleep 05
log_info " "
log_info "===== Build Information ====="
log_info "Android Version: $(getprop ro.build.version.release)"
log_info "SDK Version: $(getprop ro.build.version.sdk)"
log_info "Build ID: $(getprop ro.build.id)"
log_info "Build Fingerprint: $(getprop ro.build.fingerprint)"
log_info "Build Type: $(getprop ro.build.type)"
sleep 05
log_info " "
log_info "===== Kernel Information ====="
log_info "Kernel Version: $(uname -r)"
sleep 05
log_info "===== SELinux Status ====="
log_info "SELinux: $(getenforce)"
sleep 05
ui_print "Device info collection complete."
ui_print "You can view it in: $INFOFILE"
echo "   _____________  __ ______
  / ____/ ____/ |/ // ____/
 / / __/ __/  |   //___ \  
/ /_/ / /___ /   |____/ /  
\____/_____//_/|_/_____/   
                           "
# Set permissions for the Gex binary and system/bin recursively.
set_perm 0 0 0755 $MODPATH/system/bin/gex
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755

ui_print "$MODNAME installed successfully!"