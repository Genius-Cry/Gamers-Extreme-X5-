#!/system/bin/sh
# Uninstall script for SafeEFootballPerformance

MODDIR="/data/adb/modules/gamers.extreme.x5"
[ -d "$MODDIR" ] && rm -rf "$MODDIR"
