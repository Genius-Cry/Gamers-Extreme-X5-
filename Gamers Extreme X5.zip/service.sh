#!/system/bin/sh
# Gamers Extreme X5 - Universal Gaming Optimization Service
# Optimizes FPS, RAM, battery, and multitasking while allowing manual mode switching.

GAMES_LIST="/data/adb/modules/gamers.extreme.x5/games_list.txt"
MANUAL_MODE_FILE="/data/adb/modules/gamers.extreme.x5/manual_mode.txt"
LOGFILE="/data/local/tmp/gex_mode.log"

# Ensure files exist
if [ ! -f "$GAMES_LIST" ]; then
    mkdir -p "$(dirname "$GAMES_LIST")"
    cat > "$GAMES_LIST" <<EOF
com.pubg.krmobile
com.tencent.ig
com.activision.callofduty.shooter
com.dts.freefireth
com.supercell.clashroyale
com.miHoYo.GenshinImpact
com.mojang.minecraftpe
com.epicgames.fortnite
com.ea.gp.apexlegendsmobile
com.riotgames.league.wildrift
com.innersloth.spacemafia
com.roblox.client
com.supercell.brawlstars
com.kiloo.subwaysurf
com.king.candycrushsaga
jp.konami.pesam
com.supercell.clashofclans
EOF
fi

if [ ! -f "$MANUAL_MODE_FILE" ]; then
    echo "auto" > "$MANUAL_MODE_FILE"
fi

current_mode="balance"

# --- Performance Mode Optimizations ---
set_performance_mode() {
    echo "$(date): Switching to Performance Mode" >> "$LOGFILE"

    # Max Performance Scaling
    [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor ] && echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    
    # GPU Boost
    [ -e /sys/class/kgsl/kgsl-3d0/devfreq/governor ] && echo "high" > /sys/class/kgsl/kgsl-3d0/devfreq/governor
    
    # High Refresh Rate
    [ -e /sys/class/graphics/fb0/refresh_rate ] && echo 90 > /sys/class/graphics/fb0/refresh_rate
    
    # RAM Optimization
    [ -e /proc/sys/vm/swappiness ] && echo 10 > /proc/sys/vm/swappiness
    [ -e /proc/sys/vm/dirty_ratio ] && echo 1 > /proc/sys/vm/dirty_ratio
}

# --- Balance Mode Optimizations ---
set_balance_mode() {
    echo "$(date): Switching to Balance Mode" >> "$LOGFILE"

    [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor ] && echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    [ -e /sys/class/graphics/fb0/refresh_rate ] && echo 60 > /sys/class/graphics/fb0/refresh_rate
    [ -e /proc/sys/vm/swappiness ] && echo 30 > /proc/sys/vm/swappiness
    [ -e /proc/sys/vm/dirty_ratio ] && echo 10 > /proc/sys/vm/dirty_ratio
}

# --- Aggressive Battery Saver Mode ---
set_aggressive_battery_mode() {
    echo "$(date): Activating Aggressive Battery Saver Mode" >> "$LOGFILE"

    force_battery_mode
}

# --- Function to force immediate Battery Saver Mode ---
force_battery_mode() {
    echo "$(date): Forcing Battery Saver Mode..." >> "$LOGFILE"

    if [ -e /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor ]; then
      echo "powersave" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    fi
    if [ -e /sys/class/graphics/fb0/refresh_rate ]; then
      echo 45 > /sys/class/graphics/fb0/refresh_rate
    fi
    if [ -e /proc/sys/vm/dirty_ratio ]; then
      echo 20 > /proc/sys/vm/dirty_ratio
    fi

    echo "$(date): Battery Saver Mode Activated!" >> "$LOGFILE"
}

# --- Mode Switching ---
while true; do
    MANUAL_MODE=$(cat "$MANUAL_MODE_FILE" | tr -d '[:space:]')

    case "$MANUAL_MODE" in
        "performance") set_performance_mode && current_mode="performance";;
        "balance") set_balance_mode && current_mode="balance";;
        "battery") set_aggressive_battery_mode && current_mode="battery";;
        "battery") # Auto-detect foreground app
            current_app=$(dumpsys window windows | grep -E 'mCurrentFocus' | awk -F '[ }]' '{print $NF}')
            [ -z "$current_app" ] && current_app="unknown"
            if grep -Fxq "$current_app" "$GAMES_LIST"; then
                [ "$current_mode" != "performance" ] && set_performance_mode && current_mode="performance"
            else
                [ "$current_mode" != "balance" ] && set_balance_mode && current_mode="balance"
            fi
            ;;
    esac
    sleep 2
done